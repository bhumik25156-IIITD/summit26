import { Link } from "react-router";
import { WiseBiteLogo } from "../components/WiseBiteLogo";
import { Home as HomeIcon, GitCompare, User, Menu, Settings, ScanLine, History, Camera, Upload } from "lucide-react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { useState } from "react";

export function Scan() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: '#E0FFF5' }}>
      {/* Left Sidebar */}
      <div 
        className={`fixed left-0 top-0 h-full bg-white shadow-xl z-50 transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        <div className="p-4 border-b border-emerald-200 flex items-center justify-between">
          {sidebarOpen && (
            <span className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
              Menu
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="hover:bg-emerald-50"
          >
            <Menu className="w-5 h-5 text-emerald-600" />
          </Button>
        </div>

        <nav className="p-4 space-y-2">
          <Link to="/home">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <HomeIcon className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Home</span>}
            </div>
          </Link>

          <Link to="/scan">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white shadow-md cursor-pointer">
              <ScanLine className="w-5 h-5" />
              {sidebarOpen && <span className="font-medium">Scan</span>}
            </div>
          </Link>

          <Link to="/recent-scans">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <History className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Recent Scans</span>}
            </div>
          </Link>

          <Link to="/compare">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <GitCompare className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Compare</span>}
            </div>
          </Link>

          <Link to="/profile">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <User className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Profile</span>}
            </div>
          </Link>

          <Link to="/settings">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <Settings className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Settings</span>}
            </div>
          </Link>
        </nav>
      </div>

      {/* Main Content */}
      <div 
        className={`transition-all duration-300 ${
          sidebarOpen ? 'ml-64' : 'ml-20'
        }`}
      >
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-emerald-200">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-end items-center gap-3">
              <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                WiseBite
              </span>
              <WiseBiteLogo size={45} />
            </div>
          </div>
        </header>

        {/* Centered Scan Interface */}
        <main className="min-h-[calc(100vh-80px)] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
          <div className="w-full max-w-2xl">
            <Card className="border-4 border-emerald-300 shadow-2xl">
              <CardContent className="p-12">
                {/* Scanner Icon at Top */}
                <div className="flex justify-center mb-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center shadow-lg">
                    <ScanLine className="w-12 h-12 text-white" />
                  </div>
                </div>

                {/* Camera Frame */}
                <div className="mb-8">
                  <div className="aspect-video bg-gradient-to-br from-emerald-50 to-green-50 rounded-3xl border-4 border-emerald-300 border-dashed flex items-center justify-center relative overflow-hidden">
                    {/* Camera Placeholder Icon */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="w-32 h-32 text-emerald-300" />
                    </div>
                    
                    {/* Scanning Animation Lines */}
                    <div className="absolute inset-0 flex flex-col justify-center space-y-4 px-8">
                      <div className="h-1 bg-emerald-400 rounded-full opacity-30"></div>
                      <div className="h-1 bg-emerald-400 rounded-full opacity-30"></div>
                      <div className="h-1 bg-emerald-400 rounded-full opacity-30"></div>
                    </div>
                  </div>
                </div>

                {/* Message */}
                <div className="text-center mb-8">
                  <p className="text-xl text-gray-700 leading-relaxed">
                    Take a photo or upload an image of a product barcode or ingredient label.
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="space-y-4">
                  <Button 
                    size="lg" 
                    className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-xl text-lg font-semibold shadow-lg hover:shadow-xl transition-all py-6"
                  >
                    <Camera className="w-6 h-6 mr-3" />
                    Take Photo
                  </Button>

                  <Button 
                    size="lg" 
                    variant="outline"
                    className="w-full border-2 border-emerald-400 text-emerald-700 hover:bg-emerald-50 rounded-xl text-lg font-semibold py-6"
                  >
                    <Upload className="w-6 h-6 mr-3" />
                    Upload Image
                  </Button>
                </div>

                {/* Analyze Button */}
                <div className="mt-8 pt-8 border-t-2 border-emerald-200">
                  <Button 
                    size="lg" 
                    className="w-full bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-500 hover:from-emerald-600 hover:via-green-600 hover:to-emerald-600 text-white rounded-full text-xl font-bold shadow-2xl py-7"
                  >
                    Analyze Product Image
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Helper Text */}
            <p className="text-center text-gray-600 mt-6 text-sm">
              Supported formats: JPG, PNG, HEIC • Max size: 10MB
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
