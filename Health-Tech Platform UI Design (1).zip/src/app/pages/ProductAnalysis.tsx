import { useParams, Link } from "react-router";
import { WiseBiteLogo } from "../components/WiseBiteLogo";
import { ArrowLeft, AlertTriangle, Info, ShieldAlert, Leaf, Package, Sparkles, Home as HomeIcon, GitCompare, User, Menu, Settings, ScanLine, History } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "../components/ui/alert";
import { mockProducts } from "../data/mockData";
import { useState } from "react";

export function ProductAnalysis() {
  const { id } = useParams();
  const product = mockProducts.find((p) => p.id === id);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  if (!product) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: '#E0FFF5' }}>
        <div className="max-w-7xl mx-auto px-4 py-8">
          <p>Product not found</p>
        </div>
      </div>
    );
  }

  const personalizedHazards = product.ingredients.filter(
    (ing) => ing.status === "warning" || ing.status === "danger"
  );

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: '#E0FFF5' }}>
      {/* Left Sidebar */}
      <div 
        className={`fixed left-0 top-0 h-full bg-white shadow-xl z-50 transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        <div className="p-4 border-b border-emerald-200 flex items-center justify-between">
          {sidebarOpen && (
            <span className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
              Menu
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="hover:bg-emerald-50"
          >
            <Menu className="w-5 h-5 text-emerald-600" />
          </Button>
        </div>

        <nav className="p-4 space-y-2">
          <Link to="/home">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <HomeIcon className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Home</span>}
            </div>
          </Link>

          <Link to="/scan">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <ScanLine className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Scan</span>}
            </div>
          </Link>

          <Link to="/recent-scans">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <History className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Recent Scans</span>}
            </div>
          </Link>

          <Link to="/compare">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <GitCompare className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Compare</span>}
            </div>
          </Link>

          <Link to="/profile">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <User className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Profile</span>}
            </div>
          </Link>

          <Link to="/settings">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 text-gray-700 cursor-pointer transition-all">
              <Settings className="w-5 h-5 text-emerald-600" />
              {sidebarOpen && <span className="font-medium">Settings</span>}
            </div>
          </Link>
        </nav>
      </div>

      {/* Main Content */}
      <div 
        className={`transition-all duration-300 ${
          sidebarOpen ? 'ml-64' : 'ml-20'
        }`}
      >
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-emerald-200">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <Link to="/recent-scans">
                <Button variant="ghost" className="hover:bg-emerald-50 text-emerald-600 rounded-full">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Recent Scans
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  WiseBite
                </span>
                <WiseBiteLogo size={45} />
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Product Header */}
          <Card className="mb-6 border-3 border-emerald-300 shadow-xl">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="w-full md:w-48 h-48 bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl overflow-hidden flex-shrink-0 border-2 border-emerald-200 shadow-lg">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-2xl">🎋</span>
                    <p className="text-sm text-emerald-600 font-semibold">{product.brand}</p>
                  </div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent mb-4">
                    {product.name}
                  </h1>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-gradient-to-r from-emerald-100 to-green-100 text-emerald-700 border-2 border-emerald-300">
                      Scanned {new Date(product.scanDate).toLocaleDateString()}
                    </Badge>
                    {product.recallStatus && (
                      <Badge className="bg-gradient-to-r from-red-400 to-orange-400 text-white border-none">
                        Recall Active
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Score */}
          <Card className="mb-6 border-3 border-emerald-300 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-green-50 border-b-2 border-emerald-200">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-emerald-600" />
                <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  Overall Health Assessment
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="flex-shrink-0 text-center">
                  <div className="text-6xl font-bold mb-2" style={{
                    color:
                      product.healthScore >= 80
                        ? "#10b981"
                        : product.healthScore >= 60
                        ? "#f59e0b"
                        : product.healthScore >= 40
                        ? "#f97316"
                        : "#ef4444",
                  }}>
                    {product.healthScore}
                  </div>
                  <div className="text-sm text-gray-500">Health Score</div>
                </div>
                <div className="flex-1 space-y-4">
                  <div className="bg-gradient-to-br from-emerald-50 to-green-50 p-5 rounded-2xl border-2 border-emerald-200">
                    <h3 className="font-bold text-gray-900 mb-2 text-lg">Risk Assessment</h3>
                    <p className="text-gray-700 leading-relaxed">
                      This product has been analyzed against your personal health profile. 
                      {product.healthScore >= 80 && " This is a safe choice for your dietary needs. 🎋"}
                      {product.healthScore >= 60 && product.healthScore < 80 && " This product contains some ingredients to be aware of. 🌿"}
                      {product.healthScore < 60 && " This product contains ingredients that may pose risks based on your health profile. ⚠️"}
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-gradient-to-br from-emerald-100 to-white p-3 rounded-2xl border-2 border-emerald-200 text-center">
                      <p className="text-xs text-emerald-600 font-semibold mb-1">Ingredients</p>
                      <p className="text-xl font-bold text-gray-900">{product.ingredients.length}</p>
                    </div>
                    <div className="bg-gradient-to-br from-green-100 to-white p-3 rounded-2xl border-2 border-green-200 text-center">
                      <p className="text-xs text-green-600 font-semibold mb-1">Packaging</p>
                      <p className="text-xl font-bold text-gray-900">{product.packagingScore}/100</p>
                    </div>
                    <div className="bg-gradient-to-br from-emerald-100 to-white p-3 rounded-2xl border-2 border-emerald-200 text-center">
                      <p className="text-xs text-emerald-600 font-semibold mb-1">Alerts</p>
                      <p className="text-xl font-bold text-gray-900">{product.alerts.length}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-2 gap-6 mb-6">
            {/* Allergen Alerts */}
            <Card className="border-3 border-red-300 shadow-xl">
              <CardHeader className="bg-gradient-to-br from-red-50 to-pink-50 border-b-2 border-red-200">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ShieldAlert className="w-5 h-5 text-red-500" />
                  <span className="bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                    Allergen Alerts
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {personalizedHazards.length > 0 ? (
                  <div className="space-y-3">
                    {personalizedHazards.map((ingredient, idx) => (
                      <Alert key={idx} className="border-2 border-red-300 bg-gradient-to-r from-red-50 to-pink-50">
                        <AlertTriangle className="h-5 w-5 text-red-500" />
                        <AlertTitle className="text-red-800 font-bold">{ingredient.name}</AlertTitle>
                        <AlertDescription className="text-red-700">
                          {ingredient.reason || "This ingredient conflicts with your health profile"}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-3 text-green-600 bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border-2 border-green-300">
                    <Info className="w-6 h-6" />
                    <p className="font-semibold">No allergen alerts detected 🌸</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Packaging Safety */}
            <Card className="border-3 border-emerald-300 shadow-xl">
              <CardHeader className="bg-gradient-to-br from-emerald-50 to-green-50 border-b-2 border-emerald-200">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Package className="w-5 h-5 text-emerald-600" />
                  <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                    Packaging Safety
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-gradient-to-r from-emerald-50 to-green-50 p-4 rounded-2xl border-2 border-emerald-200">
                    <span className="font-semibold text-gray-700">Safety Score</span>
                    <span className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                      {product.packagingScore}/100
                    </span>
                  </div>
                  <div className="space-y-3 pt-2">
                    <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-green-200">
                      <div className="w-3 h-3 bg-green-400 rounded-full mt-1.5"></div>
                      <div>
                        <p className="font-semibold text-gray-900">BPA-Free</p>
                        <p className="text-sm text-gray-600">No bisphenol detected</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-green-200">
                      <div className="w-3 h-3 bg-green-400 rounded-full mt-1.5"></div>
                      <div>
                        <p className="font-semibold text-gray-900">Recyclable Material</p>
                        <p className="text-sm text-gray-600">Eco-friendly packaging</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-amber-200">
                      <div className="w-3 h-3 bg-amber-400 rounded-full mt-1.5"></div>
                      <div>
                        <p className="font-semibold text-gray-900">Handling Notice</p>
                        <p className="text-sm text-gray-600">Wash hands after handling</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recall Notice */}
          {product.recallStatus && (
            <Alert className="mb-6 border-4 border-red-400 bg-gradient-to-r from-red-50 to-pink-50">
              <AlertTriangle className="h-6 w-6 text-red-500" />
              <AlertTitle className="text-xl text-red-800 font-bold">FDA Recall Notice</AlertTitle>
              <AlertDescription className="text-base text-red-700">
                This product is currently under an active recall. Do not consume and return to place of purchase.
              </AlertDescription>
            </Alert>
          )}

          {/* Ingredient Analysis */}
          <Card className="border-3 border-emerald-300 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 via-green-50 to-emerald-50 border-b-2 border-emerald-200">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Leaf className="w-6 h-6 text-green-500" />
                <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  Ingredient Analysis
                </span>
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Complex ingredients explained in simple terms 🎋
              </p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {product.ingredients.map((ingredient, idx) => (
                  <div
                    key={idx}
                    className={`p-5 rounded-2xl border-l-4 shadow-md ${
                      ingredient.status === "safe"
                        ? "bg-gradient-to-r from-green-50 to-emerald-50 border-l-green-500"
                        : ingredient.status === "warning"
                        ? "bg-gradient-to-r from-amber-50 to-yellow-50 border-l-amber-500"
                        : ingredient.status === "danger"
                        ? "bg-gradient-to-r from-red-50 to-pink-50 border-l-red-500"
                        : "bg-gradient-to-r from-gray-50 to-slate-50 border-l-gray-300"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 mb-2 text-lg">
                          {ingredient.name}
                        </h4>
                        <p className="text-gray-700 mb-2 leading-relaxed">
                          {ingredient.simplified}
                        </p>
                        {ingredient.reason && (
                          <p className="text-sm font-semibold text-red-700 flex items-center gap-1">
                            ⚠️ {ingredient.reason}
                          </p>
                        )}
                      </div>
                      <Badge
                        className={`${
                          ingredient.status === "safe"
                            ? "bg-gradient-to-r from-green-400 to-emerald-400 text-white border-none"
                            : ingredient.status === "warning"
                            ? "bg-gradient-to-r from-amber-400 to-yellow-400 text-white border-none"
                            : ingredient.status === "danger"
                            ? "bg-gradient-to-r from-red-400 to-pink-400 text-white border-none"
                            : "bg-gradient-to-r from-gray-400 to-slate-400 text-white border-none"
                        }`}
                      >
                        {ingredient.status === "safe" && "Safe"}
                        {ingredient.status === "warning" && "Caution"}
                        {ingredient.status === "danger" && "Risk"}
                        {ingredient.status === "caution" && "Monitor"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
